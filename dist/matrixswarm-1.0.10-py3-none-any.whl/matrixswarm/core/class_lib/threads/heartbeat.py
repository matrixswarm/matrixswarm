class Heartbeat:


    def open_boot_log(self):
        self.was_success = False
